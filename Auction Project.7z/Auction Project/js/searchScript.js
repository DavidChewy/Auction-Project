async function fetchLots(search) {
    let uic = document.getElementById("txtHint"); // create new variable and call the id "txtHint"

    // Bail if the string length is too short to search
    if (search.length < 2) { // if the search length is less than 2, then return nothing.
        uic.innerHTML = ""; // sets the innerHTML of the search to nothing.
        return; // returns the if Statement
    }

    try {
        const res = await fetch("Ajax/ajaxSearch.php?q=" + search + "&token=<?php echo $token; ?>"); // used a try method, get the URL of the ajaxSearch and get the token. this is constant.
        const data = await res.json(); // const data, will wait 

        // Data is valid
        if (data.length > 0) { // if the data is less than 0 then use this if statement

            uic.innerHTML = ""; // then make the uic variable to nothing

            data.forEach(function (obj) { // for each method
                let showImages = document.getElementById("showimages").checked;
                uic.innerHTML += '<li class="list-group-item"><p>' + (showImages ? '<img width="70px" class="img-thumbnail" src= ../images/' + obj._images[0].path + '>' : '') + obj.lot_name + "</p></li></a>";
            });
        } else {
            // Add no data found message
            uic.innerHTML = `<p>No results found...</p>`
        }
    } catch(e) {
        console.log(e);
    }
}
function clearHint() {
    let uic = document.getElementById("txtHint");
    uic.innerHTML = "";
}
