// Set the date we're counting down to
vacountDownDate = ""; // set the count down to nothing.
function bidding(str, bid, userID) { // the parameters of bidding which is str, bid and userID which is refered to the URL and other methods.

    let xmlhttp = new XMLHttpRequest();
    let uic = document.getElementById("winner"); // create new variable called uic and make the id called "Winner"
    let yourBid = document.getElementById("loser");// create a new variable called yourBid and make the id called "loser"
    xmlhttp.open("GET", "Ajax/ajaxBidding.php?id=" + str + "&Bids="+ bid + "&userID=" + userID + "&token=<?php echo $token; ?>", true); // get id, Bid and userID from ajax also gets token.


    xmlhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) { //checks the status of the request of javascript. 4 == successful, 200 checking if successful as well.
            let item = JSON.parse(this.responseText); // this turns the text to a JSON file.

            item.forEach(function (obj) {
                countDownDate = new Date(obj.endDate).getTime(); // countdown date is creating a new date which gets the endDate from AuctionsDataSet.
                if(bid === "Winner"){ // if the bid = to 'winner' as a highest bid, then show the amount of the bid at the top.
                    uic.innerHTML = "The highest bidder is £" + obj.bid_amount; // this is the highest bid shown on the html format.
                }
                else if(bid === "YourBid") // else if statement to show that if you're not that highest bidder then post the users bid beneath
                {
                    yourBid.innerHTML = "Your Highest Bid is £" + obj.bid_amount; // this is the users highest bid
                }
            })
        }
    }
    xmlhttp.send();
}

let l = setInterval(function ()
{
    bidding("<?php echo $_GET['lot'];?>", "Winner", "<?php echo $user->getID() ;?>"); // call the bidding function, echo getting lot, if "winner" from ajax then get userID
    bidding("<?php echo $_GET['lot'];?>", "YourBid","<?php echo $user->getID() ;?>"); // call the bidding function, echo getting lot, "YourBid" from ajax then get userID

        // Get today's date and time
        var now = new Date().getTime(); // this variable is now which creates a new date and time.

        // Find the distance between now and the count down date
        var distance = countDownDate - now; // countdown date minus the current date.

        // Time calculations for days, hours, minutes and seconds
        var days = Math.floor(distance / (1000 * 60 * 60 * 24)); // the solution for getting the days
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)); // the solution for getting the hours
        var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)); //the solution for getting minutes
        var seconds = Math.floor((distance % (1000 * 60)) / 1000); // the solution to get the seconds

        // Display the result in the element with id="demo"
        document.getElementById("timer").innerHTML = days + "d " + hours + "h "
            + minutes + "m " + seconds + "s "; // post this as the time cleanly to days, hours and mintues with seconds.

        // If the count down is finished, write some text
        if (distance < 0) { // if the distance = 0 then do this method
            clearInterval(l); // get the clearInterval "l" which is what I set it to for as a loop
            document.getElementById("timer").innerHTML = "EXPIRED"; // the "timer" id if the countdown / endDate = 0 then it will show a "Expired" innerHTML tag.
        }

},1000);

