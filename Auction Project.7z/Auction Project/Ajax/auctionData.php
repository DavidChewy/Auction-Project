<?php
require_once ('../Models/AuctionDataSet.php');
//require_once ('../Models/Pagination.php');


$auctionDataSet = new AuctionDataSet(); // this variable is now the new AuctionDataSet
$auctionDataSet = $auctionDataSet->fetchOneAuctions($_GET["id"]); // we get the id from the fetchOneAuctions method


// start the session
session_start();// start the session

$token = ""; // set the token to nothing
if(isset($_SESSION['ajaxToken']))  //if isset ajaxToken from the phtml then set variable token as the ajaxToken
{
    $token = $_SESSION["ajaxToken"]; // sets the variable as the session ajaxToken
}

if(!isset($_GET["token"]) || $_GET["token"] !=$token) { // if statement to get token, or get token which is not =token
    $data = new stdClass(); // new data variable to a new class
    $data->error = "No data for you"; // returns the data to a error as a message "No data for you"
    echo json_encode($data); // echo the data to a json script

}
else{
    echo json_encode($auctionDataSet); // else statement to a auctionDataSet
}
