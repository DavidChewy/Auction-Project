<?php

require_once('../Models/BidsDataSet.php');
//require_once ('../Models/Pagination.php');

// start the session
session_start();

$token = ""; // variable token is null
if (isset($_SESSION['ajaxToken'])) { // if the session started then get ajaxToken
    $token = $_SESSION["ajaxToken"]; // this variable is now ajax Token
}


if (!isset($_GET["token"]) || $_GET["token"] != $token) { // if statement if not isset token then return error
    $data = new stdClass();
    $data->error = "No data for you"; // error to show that there is no data
    echo json_encode($data); // make this data a json script

 } else { // else if you do get the token then use this statement
    $bidsDataSet = new BidsDataSet(); // the variable is now a new class
    if($_GET["Bids"] == "Winner"){  // get "Bids" which is now = to Winner
        $bidsDataSet = $bidsDataSet->fetchHighestBid($_GET["id"]); // get the "id" from the method of the sql query
    }
    if($_GET["Bids"] == "YourBid"){ // get "Bids" which is = to YourBid
        $bidsDataSet = $bidsDataSet->fetchUserBid($_GET["userID"],$_GET["id"]); // get the userID and id of that user from the query
    }
//    if($_GET["Bids"] == "Updated"){
//        $updateBids = $bidsDataSet->updateBid($_GET["bid_amount"], $_GET["userID"]);
//    }

    echo json_encode($bidsDataSet); // turns this into a script


}
