<?php
require_once ('../Models/LotsDataSet.php');
//require_once ('../Models/Pagination.php');


$lotsDataSet = new LotsDataSet(); // variable is the new lotsDataSet
$lotsDataSet = $lotsDataSet->fetchsomeLots(10,1, $_GET["q"]); // get the query from the LotsDataSet and use the parameters.


// start the session
session_start(); // start the session of the script

$token = ""; // make this token to nothing
if(isset($_SESSION['ajaxToken'])) // if isset ajaxToken from the phtml then set variable token as the ajaxToken
{
    $token = $_SESSION["ajaxToken"]; // sets the variable as the session ajaxToken
}

if(!isset($_GET["token"]) || $_GET["token"] !=$token) {  // if statement to get token, or get token which is not =token
        $data = new stdClass(); // new data variable to a new class
        $data->error = "No data for you"; // return data value to an error to print out message "No data for you"
        echo json_encode($data); // echo this data as a script



    }
else{
    echo json_encode($lotsDataSet); // else statement, echo the lotsDataSet Variable.
}
