<?php

require_once("Models/User.php");
require_once("Models/AuctionDataSet.php");
require_once("Models/LotsDataSet.php");
require_once("Models/Control.php");

$view = new Control(); // Create a Control class for displaying information
$view->setPageTitle("Homepage");

$user = new User(); // Create the user class which controls user interactions
$lotsDataSet = new LotsDataSet();
$auctionDataSet = new AuctionDataSet();
$auctionData = new stdClass();


if (isset($_POST["loginButton"])) // The login button was pressed
{
    if ($user->Authenticate(htmlspecialchars(strtolower($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["captcha"]))) // Authenticate the users details
    {
        $view->setLoginError(false); // Successfully logged in, no error to show
    } else {
        $view->setLoginError(true); // Unsuccessful login, show an error
    }
}

if (isset($_POST["signUpButton"])) // The signup button was pressed
{
    $signUpUser = $user->SignUp(htmlspecialchars($_POST["firstName"]), htmlspecialchars($_POST["lastName"]), htmlspecialchars(strtolower($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["repeatPassword"]), htmlspecialchars($_POST["captcha"])); // Attempt to sign the user up
    if (!$signUpUser) // Authenticate the users details
    {
        $view->setSignUpError(false); // Successfully signed up, no error to show
        $user->Authenticate(strtolower(htmlspecialchars($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["captcha"]));
    } else {
        $view->setSignUpError($signUpUser); // Unsuccessful signup, show an error
    }
}

if (isset($_POST["logoutButton"])) // The logout button was pressed
{
    $user->logout(); // Call the logout method
}

if (isset($_POST["controlPanelButton"])) // The control panel was opened
{
    if ($lotsDataSet->addNewLot(htmlspecialchars($_POST["lotName"]), htmlspecialchars($_POST["estimatedValue"]), htmlspecialchars($_POST["description"]), htmlspecialchars($_POST["auctionID"]))) // Check the lot details are correct
    {
        $lotID = $lotsDataSet->fetchNewLotID(htmlspecialchars($_POST["lotName"]), htmlspecialchars($_POST["estimatedValue"]), htmlspecialchars($_POST["description"]), htmlspecialchars($_POST["auctionID"])); // Get the newly generated lots ID
        $count = 1;
        while ($count < 4) { // Iterate 3 new images
            $path = "Imagescar" . $lotID . "-" . $count++ . ".jpg"; // Format of the images
            $lotsDataSet->addNewImages($path, $lotID); // Add them to the DB
        }
        $view->setNewLotError(false); // Successfully created a new lot
    } else {
        $view->setNewLotError("There has been an error in one or more values you have entered!");
    }
}

$auctionData->auctionDataSet = $auctionDataSet->fetchAuctions();

require_once("Views/index.phtml");