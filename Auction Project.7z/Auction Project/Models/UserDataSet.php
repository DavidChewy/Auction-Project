<?php

require_once('Models/Database.php');
require_once('Models/UserData.php');

class UserDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function authenticateUser($email, $password)
    {
        // Question marks represent values to be replaced via binding
        $statement = $this->_dbHandle->prepare("SELECT * FROM userData WHERE email = ? AND password = ?"); // Prepare a PDO statement and implement binding
        $statement->bindParam(1, $email);
        $statement->bindParam(2, $password);
        $statement->execute(); // Execute the PDO statement with the bound parameters

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new UserData($row);
        }
        return $dataSet;
    }
        // check this out again for sql compare to your old one
    public function signUpUser($firstName, $lastName, $email, $password)
    {
        $sqlQuery = "INSERT INTO Users (first_name, last_name, email, password) VALUES(?, ?, ?, ?);";

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->bindParam(1, $firstName);
        $statement->bindParam(2, $lastName);
        $statement->bindParam(3, $email);
        $statement->bindParam(4, $password);
        return $statement->execute();
    }
}