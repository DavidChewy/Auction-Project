<?php

class UserData
{

    protected $_id, $_firstName, $_lastName, $_email, $_password;

    public function __construct($dbRow)
    { // Take variables from row of result
        $this->_id = $dbRow['id'];
        $this->_firstName = $dbRow['first_name'];
        $this->_lastName = $dbRow['last_name'];
        $this->_email = $dbRow['email'];
        $this->_password = $dbRow['password'];
    }

    // Getter methods

    public function getUserID()
    {
        return $this->_id;
    }

    public function getFirstName()
    {
        return $this->_firstName;
    }

    public function getLastName()
    {
        return $this->_lastName;
    }

    public function getEmail()
    {
        return $this->_email;
    }

    public function getPassword()
    {
        return $this->_password;
    }
}