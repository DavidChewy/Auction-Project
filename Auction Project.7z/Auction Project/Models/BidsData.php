<?php

class BidsData implements JsonSerializable {
    
    protected $_bidAmount, $_bidTime;
    
    public function __construct($dbRow) { // Take variables from row of result
        $this->_bidAmount = $dbRow['bid_amount'];

        if (isset($dbRow['bid_time']))
            $this->_bidTime = $dbRow['bid_time'];
    }


    public function jsonSerialize()
    {
        // TODO: Implement jsonSerialize() method.
        return[
            'bid_amount' => $this->_bidAmount,
            'bid_time' => $this->_bidTime

    ];
    }

    // Getter methods

    public function getBid() {
        return $this->_bidAmount;
    }

    public function getBidTime() {
        return $this->_bidTime;
    }
}