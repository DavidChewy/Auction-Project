<?php

class AuctionData implements JsonSerializable {

    protected $_id, $_title, $start_date, $describ, $price, $end_date;

    public function __construct($dbRow) { // Take variables from row of result
        $this->_id = $dbRow['id'];
        $this->_title = $dbRow['title'];
        $this->start_date = $dbRow['start_date'];
        $this->describ = $dbRow['describ'];
        $this->price = $dbRow['price'];
        if((isset($dbRow['end_date'])) )
        $this->end_date =$dbRow['end_date'];
    }

    // Getter methods
    public function jsonSerialize()
    {
        return [
            'id' => $this->_id,
            'endDate' => $this->end_date,
            'time' => $this->_time,

        ];
    }


    public function getAuctionID() {
        return $this->_id;
    }


    public function getTitle() {
        return $this->_title;
    }


    public function getStartdate()
    {
        return $this->start_date;
    }

    public function getPrice(){
        return $this->price;
    }

    public function getDescrib(){
        return $this->describ;
    }

    public function getEndDate(){
        return $this->end_date;
    }
}