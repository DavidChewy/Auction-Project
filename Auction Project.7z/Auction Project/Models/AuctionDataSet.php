<?php

require_once ('Database.php');
require_once('AuctionData.php');

class AuctionDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAuctions()
    {
        $sqlQuery = "SELECT id, title, describ, price, start_date FROM Auction;"; // Fetch specific things from the auction
        $statement = $this->_dbHandle->prepare($sqlQuery);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new AuctionData($row);
        }
        return $dataSet;
    }

    public function fetchOneAuctions($id)
    {
        $sqlQuery = "SELECT id, title, describ, price, time, end_date FROM Auction WHERE id = 1 LIMIT 1;"; // Fetch all of the auctions
        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $id);
        $statement->execute();


        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new AuctionData($row);
        }

        return $dataSet;
    }
}