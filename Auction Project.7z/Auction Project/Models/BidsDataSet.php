<?php

require_once ('Database.php');
require_once('BidsData.php');

class BidsDataSet
{
    protected $_dbHandle, $_dbInstance;
        
    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchUserBid($userID, $lotID)
    {
        // Question marks represent values to be replaced via binding
        $sqlQuery = "SELECT bid_amount FROM Bids INNER JOIN Lots ON Bids.lot = Lots.id INNER JOIN userData ON Bids.UserID = userData.id WHERE userData.id = ? AND Bids.Lot = ? LIMIT 1;";

        $statement = $this->_dbHandle->prepare($sqlQuery); // Prepare a statement with PDO

        // Bind parameters to prevent SQL injection
        $statement->bindParam(1, $userID);
        $statement->bindParam(2, $lotID);
        $statement->execute(); // Execute the PDO statement prepared earlier

        $dataSet = []; // Create an array to store all the results
        while ($row = $statement->fetch()) {
            $dataSet[] = new BidsData($row); // Allows access to individual column data
        }
        return $dataSet; // Return
    }

    public function fetchHighestBid($id)
    {
        $sqlQuery = "SELECT * FROM Bids INNER JOIN Lots ON Bids.Lot = Lots.id WHERE Bids.Lot = ? ORDER BY bid_amount DESC LIMIT 1;";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $id);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new BidsData($row);
        }
        return $dataSet;
    }

    public function makeNewBid($bid_amount, $userID, $lotID)
    {
        $sqlQuery = "INSERT INTO Bids (bid_amount, userID, Lot) VALUES(?, ?, ?);";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $bid_amount);
        $statement->bindParam(2, $userID);
        $statement->bindParam(3, $lotID);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new BidsData($row);
        }
        return $dataSet;
    }

    public function updateBid($bid_amount, $userID, $lotID)
    {
        $sqlQuery = "UPDATE Bids SET bid_amount = ? WHERE userID = ? AND Lot = ?;";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $bid_amount);
        $statement->bindParam(2, $userID);
        $statement->bindParam(3, $lotID);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new BidsData($row);
        }
        return $dataSet;
    }
}