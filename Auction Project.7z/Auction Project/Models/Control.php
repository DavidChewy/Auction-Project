<?php

class Control
{
    protected $_pageTitle, $_loginError, $_signUpError, $_newLotError, $_bidError;

    public function __construct()
    {
        $this->_pageTitle = "";
        $this->_loginError = false;
        $this->_signUpError = false;
        $this->_newLotError = false;
        $this->_bidError = false;
    }

    //Setter methods
    public function setLoginError($_loginError)
    {
        $this->_loginError = $_loginError;
    }

    public function setPageTitle($_pageTitle)
    {
        $this->_pageTitle = $_pageTitle;
    }

    public function setSignUpError($_signUpError)
    {
        $this->_signUpError = $_signUpError;
    }

    public function setNewLotError($_newLotError)
    {
        $this->_newLotError = $_newLotError;
    }

    public function setBidError($_bidError)
    {
        $this->_bidError = $_bidError;
    }

    // Getter methods
    public function getLoginError()
    {
        return $this->_loginError;
    }

    public function getPageTitle()
    {
        return $this->_pageTitle;
    }

    public function getNewLotError()
    {
        return $this->_newLotError;
    }

    public function getSignUpError()
    {
        return $this->_signUpError;
    }

    public function getBidError()
    {
        return $this->_bidError;
    }
}