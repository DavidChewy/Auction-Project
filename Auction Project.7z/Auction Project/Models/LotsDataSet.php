<?php

require_once ('Database.php');
require_once('LotsData.php');

class LotsDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchNumberOfResults($text)
    {
        // Question marks represent values to be replaced via binding
        $sqlQuery = "SELECT COUNT(Lots.id) as total FROM Lots, Auction WHERE Lots.auctionID = Auctions.id AND Lots.lot_name LIKE ?;"; // Count the total number of results for performance improvement

        $statement = $this->_dbHandle->prepare($sqlQuery); // Prepare a statement with PDO

        // Bind parameters to prevent SQL injection
        $text = "%" . $text . "%"; // % operators for the LIKE reserved word
        $statement->bindParam(1, $text);
        $statement->execute(); // Execute the PDO statement prepared earlier

        return $statement->fetch()['total']; // Return the total number of results
    }

    public function fetchSomeLots($limit, $offset, $text)
    {
//        $sqlQuery = "SELECT MIN(path) as path, Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip, Lots.auctionID
//                        FROM images,Lots, Auction
//                        WHERE Lots.auctionID = Auction.id
//                        AND Lots.id = images.lotID
//                        AND Lots.lot_name LIKE ?
//                        GROUP BY images.lotid LIMIT  ". $limit . " , " . $offset . ";";

        $sqlQuery = "SELECT * FROM Lots
                    WHERE Lots.lot_name LIKE ?
                    LIMIT ". $limit . " , " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $text = "%" . $text . "%";
        $statement->bindParam(1, $text);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $lotData = new LotsData($row);
            $lotData->fetchImages();

            $dataSet[] = $lotData;
        }
        return $dataSet;
    }

    public function fetchAllLots($limit, $offset, $auctionID)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots, Auction WHERE Lots.auctionID = Auction.id AND Auction.id = ? LIMIT " . $limit . ", " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $auctionID);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);
        }
        return $dataSet;
    }

    public function fetchSingleLot($id)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots INNER JOIN Auction ON Auction.id = Lots.auctionID WHERE Lots.id = ? LIMIT 1;";
        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $id);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);
        }
        return $dataSet;
    }

    public function fetchLotImages($id, $limit)
    {
        $sqlQuery = "SELECT path FROM images INNER JOIN Lots ON images.lotId = Lots.id WHERE Lots.id = ? LIMIT " . $limit . ";";
        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $id);
        $statement->execute();

        return $statement->fetchAll();
    }

    public function fetchNewLotID($lotName, $estimatedValue, $description, $auctionID)
    {
        $sqlQuery = "SELECT id FROM Lots WHERE lot_name = ? AND estimated_value = ? AND description = ? AND auctionID = ? LIMIT 1;";

        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $lotName);
        $statement->bindParam(2, $estimatedValue);
        $statement->bindParam(3, $description);
        $statement->bindParam(4, $auctionID);
        $statement->execute();

        return $statement->fetch()['id']; // Return the id
    }

    public function addNewLot($lotName, $estimatedValue, $description, $auctionID)
    {
        $sqlQuery = "INSERT INTO Lots (lot_name, estimated_value, description, auctionID) VALUES(?, ?, ?, ?);";
        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $lotName);
        $statement->bindParam(2, $estimatedValue);
        $statement->bindParam(3, $description);
        $statement->bindParam(4, $auctionID);

        return $statement->execute(); // Return the state of the query true/false
    }

    public function addNewImages($path, $lotID)
    {
        $sqlQuery = "INSERT INTO images (path, lotID) VALUES(?, ?);";
        $statement = $this->_dbHandle->prepare($sqlQuery);

        $statement->bindParam(1, $path);
        $statement->bindParam(2, $lotID);

        return $statement->execute();
    }

    public function sortByTitleAZ($limit, $offset, $text)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots INNER JOIN Auction ON Lots.auctionID = Auction.id WHERE Lots.lot_name LIKE ? ORDER BY Lots.lot_name LIMIT " . $limit . ", " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $text = "%" . $text . "%";
        $statement->bindParam(1, $text);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);
        }
        return $dataSet;
    }


    public function sortByTitleZA($limit, $offset, $text)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots INNER JOIN Auction ON Lots.auctionID = Auction.id WHERE Lots.lot_name LIKE ? ORDER BY Lots.lot_name DESC LIMIT " . $limit . ", " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $text = "%" . $text . "%";
        $statement->bindParam(1, $text);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);

        }
        return $dataSet;
    }


    public function sortByPriceHigh($limit, $offset, $text)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots INNER JOIN Auction ON Lots.auctionID = Auction.id WHERE Lots.lot_name LIKE ? ORDER BY Lots.estimated_value DESC LIMIT " . $limit . ", " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $text = "%" . $text . "%";
        $statement->bindParam(1, $text);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);

        }
        return $dataSet;
    }

    public function sortByPriceLow($limit, $offset, $text)
    {
        $sqlQuery = "SELECT Lots.id, Lots.lot_name, Lots.estimated_value, Lots.descrip FROM Lots INNER JOIN Auction ON Lots.auctionID = Auction.id WHERE Lots.lot_name LIKE ? ORDER BY Lots.estimated_value ASC LIMIT " . $limit . ", " . $offset . ";";

        $statement = $this->_dbHandle->prepare($sqlQuery);
        $text = "%" . $text . "%";
        $statement->bindParam(1, $text);
        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()) {
            $dataSet[] = new LotsData($row);

        }
        return $dataSet;
    }
}