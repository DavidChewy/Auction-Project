<?php

class LotsData implements JsonSerializable
{

    protected $_id, $_lotName, $_value, $_descrip,$_auctionID,$_images;

    public function __construct($dbRow)
    { // Take variables from row of result
        $this->_id = $dbRow['id'];
        $this->_lotName = $dbRow['lot_name'];
        $this->_value = $dbRow['estimated_value'];
        $this->_descrip = $dbRow['descrip'];
        if (isset($dbRow['auctionID'])) {
            $this->_auctionID = $dbRow['auctionID'];
        }
        if (isset($dbRow['_images'])){
            $this->_images = $dbRow['_images'];
        }
    }


    public function fetchImages($limit = 1) {
        $lotsDataSet = new LotsDataSet();

        // Call the fetch images for our own ID
        $this->_images = $lotsDataSet->fetchLotImages($this->_id, $limit);
    }


    public function jsonSerialize()
    {
        // TODO: Implement jsonSerialize() method.
        return[
        'lotId' => $this->_id,
        'lot_name' => $this->_lotName,
         '_images'=> $this->_images
        ];

    }

    // Getter methods

    public function getLotID()
    {
        return $this->_id;
    }

    public function getLotName()
    {
        return $this->_lotName;
    }

    public  function getValue()
    {
        return $this->_value; // returns the value from ItemLots
    }

    public function getAuctionID()
    {
        return $this->_auctionID; // returns the auction ID from ItemLots
    }

    public function getDescrip()
    {
        return $this->_descrip;
    }

    public function getImages(){

        return $this->_images;
    }
}