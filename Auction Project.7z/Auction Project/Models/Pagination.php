<?php

require_once("Models/LotsDataSet.php");

class Pagination
{
    protected $resultsPerPage, $numberOfPages, $dataSet;

    public function __construct($resultsPerPage, $dataSet)
    {
        $this->resultsPerPage = $resultsPerPage; // Defines the number of results per page
        $this->dataSet = $dataSet;
    }

    public function numberOfPages($text)
    {
        $noOfResults = $this->dataSet->fetchNumberOfResults($text); // Total number of results
        $this->numberOfPages = ceil($noOfResults / $this->resultsPerPage); // Calculate number of pages
        return $this->numberOfPages;
    }

    public function getRecords($currentPage, $text)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->fetchSomeLots($firstResult, $this->resultsPerPage, $text);
    }

    public function fetchAllLots($currentPage, $auctionNumber)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->fetchAllLots($firstResult, $this->resultsPerPage, $auctionNumber);
    }

    // All filter options

    public function sortByTitleZA($currentPage, $text)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->sortByTitleZA($firstResult, $this->resultsPerPage, $text);
    }

    public function sortByTitleAZ($currentPage, $text)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->sortByTitleAZ($firstResult, $this->resultsPerPage, $text);
    }

    public function sortByPriceHigh($currentPage, $text)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->sortByPriceHigh($firstResult, $this->resultsPerPage, $text);
    }

    public function sortByPriceLow($currentPage, $text)
    {
        $this->dataSet = new LotsDataSet();
        $firstResult = ($currentPage - 1) * $this->resultsPerPage;
        return $this->dataSet->sortByPriceLow($firstResult, $this->resultsPerPage, $text);
    }
}