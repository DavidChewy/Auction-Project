<?php

require_once("UserDataSet.php");

class User
{
    protected $_email, $_loggedIn, $_userID;

    public function __construct()
    {
        session_start();

        // Default state
        $this->_email = "No user";
        $this->_loggedIn = false;
        $this->_userID = "0";

        if (isset($_SESSION["login"])) // Successfully logged in
        {
            // Reassign fields
            $this->_email = $_SESSION["login"];
            $this->_userID = $_SESSION["userID"];
            $this->_loggedIn = true;
        }
    }

    public function Authenticate($email, $password, $captcha)
    {
        if ($captcha == 19) { // Check captcha
            $users = new UserDataSet();
            $userDataSet = $users->authenticateUser($email, $password); // Hash and send to authenticate
            if (count($userDataSet) == 1) // Success
            {
                // Get the details
                $_SESSION["login"] = $email;
                $_SESSION["userID"] = $userDataSet[0]->getUserID();
                $this->_loggedIn = true;
                $this->_email = $email;
                $this->_userID = $userDataSet[0]->getUserID();
                return true;
            } else {
                $this->_loggedIn = false;
            }
        }
        return false;
    }

    public function SignUp($firstName, $lastName, $email, $password, $repeatPassword, $captcha)
    {
        $error = false;
        if ($captcha == 19) {
            if (strlen($password) > 6) { // Password must be longer than 6 characters
                if ($password == $repeatPassword) { // Passwords must match
                    $users = new UserDataSet();
                    $userDataSet = $users->signUpUser($firstName, $lastName, $email, $password);
                    if (!$userDataSet) {
                        $error = "This email is already in use!";
                    }
                } else {
                    $error = "The two passwords do not match!";
                }
            } else {
                $error = "The minimum password length is 7!";
            }
        } else {
            $error = "The answer entered was incorrect!";
        }
        return $error; // Return the right error
    }

    public function logout() // Reset values and destroy the session
    {
        unset($_SESSION["login"]);
        unset($_SESSION["userID"]);
        $this->_loggedIn = false;
        $this->_email = "No user";
        $this->_adminStatus = "0";
        $this->_userID = "0";
        session_destroy();
    }

    // Getter methods

    public function isLoggedIn()
    {
        return $this->_loggedIn;
    }

    public function getEmail()
    {
        return $this->_email;
    }

    public function getID()
    {
        return $this->_userID;
    }
}