<?php

require_once("Models/User.php");
require_once('Models/BidsDataSet.php');
require_once('Models/LotsDataSet.php');
require_once("Models/Control.php");

$view = new Control(); // Create a Control class for displaying information
$view->setPageTitle("Lot");

$user = new User(); // Create the user class which controls user interactions
$lotsDataSet = new LotsDataSet();

$bidsDataSet = new BidsDataSet();
$bidData = new stdClass();

if (isset($_POST["loginButton"])) // The login button was pressed
{
    if ($user->Authenticate(htmlspecialchars(strtolower($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["captcha"]))) // Authenticate the users details
    {
        $view->setLoginError(false); // Successfully logged in, no error to show
    } else {
        $view->setLoginError(true); // Unsuccessful login, show an error
    }
}

if (isset($_POST["signUpButton"])) // The signup button was pressed
{
    $signUpUser = $user->SignUp(htmlspecialchars($_POST["firstName"]), htmlspecialchars($_POST["lastName"]), htmlspecialchars(strtolower($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["repeatPassword"]), htmlspecialchars($_POST["captcha"])); // Attempt to sign the user up
    if (!$signUpUser) // Authenticate the users details
    {
        $view->setSignUpError(false); // Successfully signed up, no error to show
        $user->Authenticate(strtolower(htmlspecialchars($_POST["email"])), htmlspecialchars($_POST["password"]), htmlspecialchars($_POST["captcha"]));
    } else {
        $view->setSignUpError($signUpUser); // Unsuccessful signup, show an error
    }
}

if (isset($_POST["logoutButton"])) // The logout button was pressed
{
    $user->logout(); // Call the logout method
}

if (isset($_GET["lot"]))
{
    $_SESSION['currentLot'] = htmlspecialchars($_GET["lot"]);
}

if (isset($_POST["controlPanelButton"])) // The control panel was opened
{
    if ($lotsDataSet->addNewLot(htmlspecialchars($_POST["lotName"]), htmlspecialchars($_POST["estimatedValue"]), htmlspecialchars($_POST["description"]), htmlspecialchars($_POST["auctionID"]))) // Check the lot details are correct
    {
        $lotID = $lotsDataSet->fetchNewLotID(htmlspecialchars($_POST["lotName"]), htmlspecialchars($_POST["estimatedValue"]), htmlspecialchars($_POST["description"]), htmlspecialchars($_POST["auctionID"])); // Get the newly generated lots ID
        $count = 1;
        while ($count < 4) { // Iterate 3 new images
            $path = "Imagescar" . $lotID . "-" . $count++ . ".jpg"; // Format of the images
            $lotsDataSet->addNewImages($path, $lotID); // Add them to the DB
        }
        $view->setNewLotError(false); // Successfully created a new lot
    } else {
        $view->setNewLotError("There has been an error in one or more values you have entered!");
    }
}

$currentID = 1;
if (isset($_SESSION['currentLot']))
{
    $currentID = $_SESSION['currentLot'];
}
$lots = $lotsDataSet->fetchSingleLot($currentID);// Get the data for the current lot

if (isset($_GET["bid"]))
{
    $bid = htmlspecialchars($_GET["bid"]); // Clear any XSS
    if (is_numeric($bid)) // Check that the bid entered is numeric
    {
        $checkBid = $bidsDataSet->fetchUserBid($user->getID(), $currentID);
        if ($checkBid)
        {
            if ($bid > $checkBid[0]->getBid()) // Compare the new bid to the old bid
            {
                $bidsDataSet->updateBid($bid, $user->getID(), $currentID); // Successful bid!
            } else {
                $view->setBidError("Please enter an amount larger than the current bid!");
            }
        } else {
            $bidsDataSet->makeNewBid($bid, $user->getID(), $currentID);
        }
    } else {
        $view->setBidError("Please enter a valid amount!");
    }
}

$bidData->highestBid = $bidsDataSet->fetchHighestBid($currentID); // Get the listing for the highest bid
$bidData->usersBid = $bidsDataSet->fetchUserBid($user->getID(), $currentID); // Get the listing for the user's highest bid

require_once("Views/lot.phtml");